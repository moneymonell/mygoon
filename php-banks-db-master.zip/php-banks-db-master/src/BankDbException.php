<?php

declare(strict_types=1);

namespace BankDb;

class BankDbException extends \Exception
{
}
